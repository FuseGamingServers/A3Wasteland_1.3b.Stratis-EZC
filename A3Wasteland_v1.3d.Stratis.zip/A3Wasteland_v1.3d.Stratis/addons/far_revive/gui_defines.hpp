// ******************************************************************************************
// * This project is licensed under the GNU Affero GPL v3. Copyright © 2014 A3Wasteland.com *
// ******************************************************************************************
//	@file Name: gui_defines.hpp
//	@file Author: AgentRev

#define ReviveBlankGUI_IDD 27910
#define ReviveGUI_IDD 27911
#define RevProgBar_IDC 27912
#define RevBarText_IDC 27913
#define RevSuicideBtn_IDC 27914
#define RevText_IDC 27915
#define RevLastResortBtn_IDC 27916
