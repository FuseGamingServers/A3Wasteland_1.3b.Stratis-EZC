#include "Configs\defines.hpp"
#include "Configs\MagRepack_Dialog_Main.hpp"
#include "Configs\MagRepack_Dialog_Keybindings.hpp"
#include "Configs\MagRepack_Dialog_About.hpp"
