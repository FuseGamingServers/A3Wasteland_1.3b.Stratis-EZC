[R3F] Artillery and Logistic : Manual artillery and advanced logistic (mission script)
--------------------------------------------------------------------------------------
You have the manual artillery and advanced logistic system for ArmA 2 and/or Arrowhead,
developed by the R3F (R�giment Force de Frappe Fran�aise, team-r3f.org).

The instructions for installing the system in a mission can be found in the file "INSTALL.pdf".

Feel free to give your feedback on the BIS topic : http://forums.bistudio.com/showthread.php?t=94280

	Copyright (C) 2010 madbull ~R3F~
	
	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

Contact : madbull@team-r3f.org


[R3F] Artillery and Logistic : Artillerie manuelle et logistique avanc�e (script de mission)
--------------------------------------------------------------------------------------------
Vous disposez du syst�me d'artillerie manuelle et de logistique avanc�e pour ArmA 2 et/ou Arrowhead,
mis au point par le R3F (R�giment Force de Frappe Fran�aise, team-r3f.org).

Les instructions d'installation du syst�me dans une mission se trouvent dans le fichier "INSTALL.pdf".

N'h�sitez pas � donner vos impressions sur le fil de discussion chez BIS : http://forums.bistudio.com/showthread.php?t=94280

	Copyright (C) 2010 madbull ~R3F~
	
	Ce programme est un logiciel libre ; vous pouvez le redistribuer ou le
	modifier suivant les termes de la "GNU General Public License" telle que
	publi�e par la Free Software Foundation : soit la version 3 de cette
	licence, soit (� votre gr�) toute version ult�rieure.
	
	Ce programme est distribu� dans l�espoir qu�il vous sera utile, mais SANS
	AUCUNE GARANTIE : sans m�me la garantie implicite de COMMERCIALISABILIT�
	ni d�AD�QUATION � UN OBJECTIF PARTICULIER. Consultez la Licence G�n�rale
	Publique GNU pour plus de d�tails.
	
	Vous devriez avoir re�u une copie de la Licence G�n�rale Publique GNU avec
	ce programme ; si ce n�est pas le cas, consultez :
	<http://www.gnu.org/licenses/>.

Contact : madbull@team-r3f.org