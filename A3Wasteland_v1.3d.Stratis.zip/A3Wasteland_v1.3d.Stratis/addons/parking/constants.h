#define GUI_BCG_RGB {"(profilenamespace getvariable ['GUI_BCG_RGB_R',0.69])","(profilenamespace getvariable ['GUI_BCG_RGB_G',0.75])","(profilenamespace getvariable ['GUI_BCG_RGB_B',0.5])","(profilenamespace getvariable ['GUI_BCG_RGB_A',0.8])"}
#define MENU_TITLE_FONT_HEIGHT (((((safezoneW / safezoneH) min 1.2) / 1.2) / 32) * 1)

#define list_simple_menu_menu_dialog_idd 6001
#define list_simple_menu_header_idc 6001
#define list_simple_menu_background_idc 6002
#define list_simple_menu_submit_button_idc 6003
#define list_simple_menu_close_button_idc 6004
#define list_simple_menu_list_idc 6005
