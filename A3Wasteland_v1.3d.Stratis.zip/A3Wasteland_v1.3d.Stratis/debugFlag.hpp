// ******************************************************************************************
// * This project is licensed under the GNU Affero GPL v3. Copyright © 2015 A3Wasteland.com *
// ******************************************************************************************
//	@file Name: debugFlag.hpp
//	@file Author: AgentRev

// THIS IS AN ADVANCED FEATURE, LEAVE #define COMMENTED (// before) IF YOU DON'T KNOW WHAT YOU'RE DOING!

//#define A3W_DEBUG

// enabling this will disable remoteExec filtering, and allow functions defined via mf_compile to be recompiled from their source file on each call
