// ******************************************************************************************
// * This project is licensed under the GNU Affero GPL v3. Copyright © 2014 A3Wasteland.com *
// ******************************************************************************************
//	@file Name: gui_defines.hpp
//	@file Author: AgentRev

#define AtmGUI_IDD 63211
#define AtmBalanceText_IDC 1010
#define AtmAmountInput_IDC 1020
#define AtmAccountDropdown_IDC 1030
#define AtmFeeText_IDC 1040
#define AtmTotalText_IDC 1050
#define AtmDepositButton_IDC 2010
#define AtmWithdrawButton_IDC 2020
#define AtmCancelButton_IDC 2030
